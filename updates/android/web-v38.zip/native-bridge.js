/*
 * APK 适配层：只在 Android 原生壳里生效（存在 window.SG2Native），
 * 预览台用 ?native=1 模拟同一环境。网页版完全不受影响。
 */
(function () {
  "use strict";

  const actualNative = window.SG2Native || null;
  const forced = /(?:^|[?&])native=1(?:&|$)/.test(location.search);
  const previewNative = {
    version: () => "1.2.0 · 网页 v37",
    updateStatus: () =>
      JSON.stringify({
        state: "uptodate",
        bundledVersion: 37,
        activeVersion: 37,
        runtimeVersion: 37,
        candidateVersion: 0,
        checking: false,
        message: "已是最新版本",
      }),
    checkForUpdates: () => {},
    confirmUpdate: () => {},
  };
  const native = actualNative || (forced ? previewNative : null);
  if (!native && !forced) return;
  window.SG2_APK_SHELL = Boolean(actualNative);
  let onboardingActive = false;

  const root = document.documentElement;
  root.classList.add("sg2-apk");

  function pageToast(message) {
    const el = document.getElementById("toast");
    if (!el) return;
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(pageToast._timer);
    pageToast._timer = setTimeout(() => el.classList.remove("show"), 2200);
  }

  function closeSheet(backdrop) {
    const closer = backdrop.querySelector("[data-close-sheet]");
    if (closer) closer.click();
    else backdrop.classList.remove("open");
  }

  /* --- 返回键：先关弹层，再回首页，最后交给系统退出 --- */
  window.SG2Back = function () {
    const openSheets = document.querySelectorAll(".sheet-backdrop.open");
    if (openSheets.length) {
      Array.prototype.forEach.call(openSheets, closeSheet);
      return true;
    }
    const dataPage = document.querySelector('[data-page-view="data"]');
    if (dataPage && !dataPage.hidden) {
      const rewardsNav = document.querySelector('[data-nav-page="rewards"]');
      if (rewardsNav) rewardsNav.click();
      return true;
    }
    return false;
  };

  /* --- 一键加群：WebView 里跳协议不一定可靠，复制完交给原生拉起 QQ --- */
  document.addEventListener(
    "click",
    (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (!target || !target.closest("#qqCopyBtn")) return;
      if (!native || typeof native.openQqGroup !== "function") return;
      const uinNode = document.querySelector(".qq-number-box strong");
      const uin = (uinNode ? uinNode.textContent : "").replace(/\D/g, "");
      // 先让页面自己完成复制和提示，再把拉起 QQ 交给原生
      setTimeout(() => {
        try {
          native.openQqGroup(uin);
        } catch (error) {
          /* 忽略 */
        }
      }, 150);
    },
    true
  );

  /* --- 领取提醒：把「下一次可领取时间」交给原生闹钟 --- */
  const REMINDER_PREF_KEY = "sg2-apk-reminders";
  const JOURNAL_KEY = "sg2-diamond-journal-v1";
  const ONBOARDING_KEY = "sg2-apk-permission-setup-v2";
  const REMINDER_TITLES = { chest: "宝箱可以领了", diamond: "钻石奖励可以领了" };

  function remindersEnabled() {
    const raw = localStorage.getItem(REMINDER_PREF_KEY);
    return raw === null ? true : raw === "1";
  }

  function clockText(timestamp) {
    const date = new Date(timestamp);
    return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
  }

  function collectReminders() {
    if (!remindersEnabled()) return [];
    let journal = null;
    try {
      journal = JSON.parse(localStorage.getItem(JOURNAL_KEY) || "null");
    } catch (error) {
      journal = null;
    }
    const current = (journal && journal.current) || {};
    const now = Date.now();
    const items = [];
    for (const kind of ["chest", "diamond"]) {
      const entry = current[kind];
      const at = entry ? Number(entry.expectedAt) : NaN;
      if (!Number.isFinite(at) || at <= now + 1000) continue;
      items.push({
        kind: kind,
        at: at,
        title: REMINDER_TITLES[kind],
        body: `${clockText(at)} 到了，回到手账点一下「下一个」记录新的时间`,
      });
    }
    return items;
  }

  function syncReminders() {
    const payload = { enabled: remindersEnabled(), items: collectReminders() };
    // 预览台会读这个对象来显示「已安排的提醒」
    window.__sg2Reminders = payload;
    if (!native || typeof native.syncReminders !== "function") return;
    try {
      native.syncReminders(JSON.stringify(payload));
    } catch (error) {
      /* 忽略 */
    }
  }

  /* 页面每次 saveData() 都会写这个 key，写完整理提醒（领取 / 撤回 / 改间隔都走这里） */
  try {
    const originalSetItem = Storage.prototype.setItem;
    Storage.prototype.setItem = function (key, value) {
      const result = originalSetItem.apply(this, arguments);
      if (key === JOURNAL_KEY) setTimeout(syncReminders, 0);
      return result;
    };
  } catch (error) {
    /* 忽略 */
  }

  /* 在设置面板里补一行「领取提醒」开关 */
  function injectReminderToggle() {
    const sheet = document.getElementById("settingsSheet");
    if (!sheet || sheet.querySelector("#sg2ReminderToggle")) return;
    const group = document.createElement("div");
    group.className = "settings-group";
    group.innerHTML =
      '<div class="group-heading"><h3>领取提醒</h3><span>可领取时发一条系统通知</span></div>' +
      '<label class="toggle-row"><span><strong>通知提醒</strong><small>宝箱和钻石都会提醒</small></span>' +
      '<input id="sg2ReminderToggle" type="checkbox"' +
      (remindersEnabled() ? " checked" : "") +
      ">" +
      '<span class="toggle" aria-hidden="true"></span></label>';
    const groups = Array.prototype.slice.call(sheet.querySelectorAll(".settings-group"));
    const anchor = groups.find ? groups.find((item) => item.textContent.indexOf("本地数据") >= 0) : null;
    if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(group, anchor);
    else sheet.appendChild(group);

    const input = group.querySelector("#sg2ReminderToggle");
    input.addEventListener("change", () => {
      localStorage.setItem(REMINDER_PREF_KEY, input.checked ? "1" : "0");
      syncReminders();
      if (input.checked && native && typeof native.requestNotificationPermission === "function") {
        try {
          native.requestNotificationPermission();
        } catch (error) {
          /* 忽略 */
        }
      }
      pageToast(input.checked ? "已开启可领取提醒" : "已关闭可领取提醒");
    });
  }

  /* --- 提醒自检：通知权限 / 精确闹钟 / 电池白名单，摊开给用户看并可跳转系统设置 --- */
  const REMINDER_CHECKS = [
    { key: "notifications", label: "通知权限", ok: "已允许", bad: "未允许", setting: "notifications" },
    { key: "exactAlarm", label: "精确闹钟", ok: "已允许", bad: "未允许", setting: "exactAlarm" },
    { key: "batteryExempt", label: "电池优化", ok: "已忽略", bad: "仍受限", setting: "battery" },
  ];

  function readReminderStatus() {
    if (!native || typeof native.reminderStatus !== "function") return null;
    try {
      const parsed = JSON.parse(native.reminderStatus());
      return parsed && typeof parsed === "object" ? parsed : null;
    } catch (error) {
      return null;
    }
  }

  function refreshReminderChecks() {
    const group = document.getElementById("sg2ReminderCheck");
    if (!group) return;
    const status = readReminderStatus();
    let missing = 0;
    const rows = group.querySelectorAll("[data-check]");
    Array.prototype.forEach.call(rows, (row) => {
      const key = row.getAttribute("data-check");
      const valueEl = row.querySelector(".check-value");
      if (!valueEl) return;
      if (!status) {
        valueEl.textContent = "预览环境";
        valueEl.className = "check-value";
        return;
      }
      const meta = REMINDER_CHECKS.find((item) => item.key === key);
      const ok = status[key] === true;
      valueEl.textContent = ok ? meta.ok : meta.bad;
      valueEl.className = "check-value " + (ok ? "is-ok" : "is-bad");
      if (!ok) missing++;
    });
    const hint = group.querySelector("[data-check-hint]");
    if (hint) {
      hint.textContent = !status
        ? "真机上这里显示实际状态；预览环境不做检查。"
        : missing === 0
          ? "三项都正常，退出应用后也能准时收到提醒。"
          : "有 " + missing + " 项没开，退出应用后可能收不到提醒，点右侧按钮去开启。";
    }
  }

  function injectReminderCheck() {
    const sheet = document.getElementById("settingsSheet");
    if (!sheet || document.getElementById("sg2ReminderCheck")) return;
    const group = document.createElement("div");
    group.className = "settings-group";
    group.id = "sg2ReminderCheck";

    const rowsHtml = REMINDER_CHECKS.map(
      (item) =>
        '<div class="check-row" data-check="' +
        item.key +
        '"><span class="check-label">' +
        item.label +
        '</span><span class="check-value">—</span>' +
        '<button class="check-button" type="button" data-open="' +
        item.setting +
        '">去开启</button></div>'
    ).join("");

    group.innerHTML =
      '<div class="group-heading"><h3>提醒自检</h3><span>退出应用也要能收到通知</span></div>' +
      rowsHtml +
      '<p class="check-hint" data-check-hint>正在检查…</p>' +
      '<button class="settings-action" type="button" data-open="testNotify">发一条测试通知</button>' +
      '<button class="settings-action" type="button" data-open="autostart">允许自启动 / 后台运行</button>' +
      '<button class="settings-action" type="button" data-open="onboarding">重新检查全部提醒设置</button>';

    group.addEventListener("click", (event) => {
      const button = event.target instanceof Element ? event.target.closest("[data-open]") : null;
      if (!button) return;
      const action = button.getAttribute("data-open");
      if (action === "onboarding") {
        injectPermissionOnboarding(true);
        return;
      }
      if (!native) {
        pageToast("预览环境：真机上会跳到系统设置");
        return;
      }
      try {
        if (action === "testNotify") {
          if (typeof native.postTestNotification === "function") native.postTestNotification();
          pageToast("已发出一条测试通知");
          return;
        }
        if (typeof native.openReminderSetting === "function") native.openReminderSetting(action);
      } catch (error) {
        pageToast("操作失败，请手动在系统设置里修改");
      }
    });

    // 放在「领取提醒」之后、「本地数据」之前
    const groups = Array.prototype.slice.call(sheet.querySelectorAll(".settings-group"));
    const dataGroup = groups.find((item) => item.textContent.indexOf("本地数据") >= 0);
    if (dataGroup && dataGroup.parentNode) {
      dataGroup.parentNode.insertBefore(group, dataGroup);
    } else {
      const saveButton = sheet.querySelector("#saveSettingsBtn");
      if (saveButton && saveButton.parentNode) saveButton.parentNode.insertBefore(group, saveButton);
      else sheet.appendChild(group);
    }

    refreshReminderChecks();
  }

  function injectPlatformCredit() {
    const actions = document.querySelector(".topbar-actions");
    if (!actions || actions.querySelector(".platform-credit-apk")) return;
    const credit = document.createElement("span");
    credit.className = "platform-credit-apk";
    credit.textContent = "APK由冰空的花束整合";
    actions.appendChild(credit);
  }

  function injectPermissionOnboarding(force = false) {
    if (!native || onboardingActive || document.getElementById("apkSetupBackdrop")) return;
    if (!force && localStorage.getItem(ONBOARDING_KEY) === "1") return;
    onboardingActive = true;

    const backdrop = document.createElement("div");
    backdrop.className = "apk-setup-backdrop";
    backdrop.id = "apkSetupBackdrop";
    backdrop.innerHTML = `
      <section class="apk-setup-card" role="dialog" aria-modal="true" aria-labelledby="apkSetupTitle">
        <span class="apk-setup-kicker">ANDROID 首次设置</span>
        <h2 id="apkSetupTitle">让到点提醒准时到达</h2>
        <p class="apk-setup-intro">请依次完成通知、精确闹钟、电池和自启动设置。不同品牌手机的名称可能略有不同。</p>
        <div class="apk-setup-list">
          <div class="apk-setup-item">
            <span><strong>通知权限</strong><small>允许钻石手账发送宝箱与钻石提醒</small></span>
            <button type="button" data-setup-action="notifications">开启</button>
          </div>
          <div class="apk-setup-item">
            <span><strong>精确闹钟</strong><small>保证在设定分钟准时触发提醒</small></span>
            <button type="button" data-setup-action="exactAlarm">去设置</button>
          </div>
          <div class="apk-setup-item">
            <span><strong>电池优化</strong><small>允许应用在后台继续保留提醒计划</small></span>
            <button type="button" data-setup-action="battery">去设置</button>
          </div>
          <div class="apk-setup-item">
            <span><strong>自启动</strong><small>在手机系统设置中允许应用自动启动</small></span>
            <button type="button" data-setup-action="autostart">去设置</button>
          </div>
        </div>
        <label class="apk-setup-lock">
          <input id="apkAutostartAck" type="checkbox" />
          <span>我已允许钻石手账自启动或后台运行。若手机没有该设置项，可跳过这一项。</span>
        </label>
        <label class="apk-setup-lock">
          <input id="apkBackgroundLockAck" type="checkbox" />
          <span>我已打开最近任务界面，并锁定/保护钻石手账。这个操作需要手动完成，Android 不允许应用自行锁定。</span>
        </label>
        <div class="apk-setup-actions">
          <button class="apk-setup-later" type="button" data-setup-later>稍后设置</button>
          <button class="apk-setup-finish" type="button" data-setup-finish>完成并发送测试通知</button>
        </div>
        <p class="apk-setup-note">自启动和后台锁定由手机厂商控制，只能在系统中手动开启。</p>
      </section>
    `;
    document.body.appendChild(backdrop);

    const refresh = () => {
      const status = readReminderStatus();
      if (!status) return;
      const labels = {
        notifications: status.notifications ? "已允许" : "未允许",
        exactAlarm: status.exactAlarm ? "已允许" : "未允许",
        batteryExempt: status.batteryExempt ? "已忽略" : "仍受限",
      };
      backdrop.querySelectorAll("[data-setup-action]").forEach((button) => {
        const action = button.getAttribute("data-setup-action");
        const row = button.closest(".apk-setup-item");
        const small = row && row.querySelector("small");
        if (!small) return;
        const label =
          action === "notifications"
            ? labels.notifications
            : action === "exactAlarm"
              ? labels.exactAlarm
              : action === "battery"
                ? labels.batteryExempt
                : "";
        if (!small.dataset.baseText) small.dataset.baseText = small.textContent;
        if (label) small.textContent = `${small.dataset.baseText} · ${label}`;
      });
    };
    refresh();

    const close = () => {
      onboardingActive = false;
      backdrop.remove();
    };

    backdrop.addEventListener("click", (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (!target) return;
      const actionButton = target.closest("[data-setup-action]");
      if (actionButton) {
        const action = actionButton.getAttribute("data-setup-action");
        try {
          if (action === "notifications") {
            if (typeof native.requestNotificationPermission === "function") {
              native.requestNotificationPermission();
            }
          } else if (typeof native.openReminderSetting === "function") {
            native.openReminderSetting(action);
          }
        } catch (error) {
          pageToast("操作失败，请手动在系统设置中修改");
        }
        return;
      }
      if (target.closest("[data-setup-later]")) {
        close();
        pageToast("可随时在设置中的“提醒自检”重新开启");
        return;
      }
      if (target.closest("[data-setup-finish]")) {
        const status = readReminderStatus();
        const autostartAck = document.getElementById("apkAutostartAck");
        const lockAck = document.getElementById("apkBackgroundLockAck");
        if (!status || !status.notifications || !status.exactAlarm || !status.batteryExempt) {
          refresh();
          pageToast("还有权限未开启，请完成后再试");
          return;
        }
        if (!autostartAck || !autostartAck.checked || !lockAck || !lockAck.checked) {
          pageToast("请先确认自启动与最近任务后台锁定");
          return;
        }
        localStorage.setItem(ONBOARDING_KEY, "1");
        localStorage.setItem(REMINDER_PREF_KEY, "1");
        syncReminders();
        try {
          if (typeof native.postTestNotification === "function") native.postTestNotification();
        } catch (error) {
          /* 通知自检仍可在设置中重新执行 */
        }
        close();
        pageToast("提醒设置完成，测试通知已发送");
      }
    });

    document.addEventListener(
      "visibilitychange",
      () => {
        if (!document.hidden) refresh();
      },
      { passive: true }
    );

    if (!readReminderStatus()?.notifications && typeof native.requestNotificationPermission === "function") {
      window.setTimeout(() => {
        try {
          native.requestNotificationPermission();
        } catch (error) {
          /* 用户仍可通过按钮重新请求 */
        }
      }, 350);
    }
  }

  /* --- 版本号：让「预览」和「实机」一眼能对上，避免拿旧包比新预览 --- */
  function injectVersionFooter() {
    const sheet = document.getElementById("settingsSheet");
    if (!sheet || document.getElementById("sg2Version")) return;
    const el = document.createElement("p");
    el.id = "sg2Version";
    el.className = "sg2-version";
    let text = "预览环境 · 未打包";
    if (native && typeof native.version === "function") {
      try {
        text = "当前版本 " + native.version();
      } catch (error) {
        text = "当前版本 读取失败";
      }
    }
    el.textContent = text;

    // 第二行：渲染环境诊断，方便一眼看出「为什么预览和实机不一样」
    const diag = document.createElement("p");
    diag.className = "sg2-version sg2-diagnostic";
    diag.textContent = renderEnvironmentInfo();

    const saveButton = sheet.querySelector("#saveSettingsBtn");
    const anchor = saveButton && saveButton.parentNode ? saveButton : null;
    if (anchor) {
      anchor.parentNode.insertBefore(el, anchor.nextSibling);
      anchor.parentNode.insertBefore(diag, el.nextSibling);
    } else {
      sheet.appendChild(el);
      sheet.appendChild(diag);
    }
  }

  function updateStatusFromNative() {
    if (!native || typeof native.updateStatus !== "function") return null;
    try {
      const status = JSON.parse(native.updateStatus());
      return status && typeof status === "object" ? status : null;
    } catch (error) {
      return null;
    }
  }

  function updateStateLabel(status) {
    if (!status) return "预览环境";
    if (status.state === "ready") {
      return status.candidateVersion
        ? "新版本 v" + status.candidateVersion + " 已就绪"
        : "新版本已就绪";
    }
    if (status.state === "installed") return "已更新到 v" + status.activeVersion;
    if (status.state === "rolled-back") return "已回退到 v" + status.activeVersion;
    if (status.state === "uptodate") return "已是最新版本";
    if (status.state === "checking") return "正在检查…";
    if (status.state === "downloading") return "正在下载更新…";
    if (status.state === "error") return "检查失败";
    return status.activeVersion ? "当前页面 v" + status.activeVersion : "尚未检查";
  }

  function refreshUpdatePanel() {
    const group = document.getElementById("sg2UpdateGroup");
    if (!group) return null;
    const status = updateStatusFromNative();
    const value = group.querySelector("[data-update-version]");
    const hint = group.querySelector("[data-update-hint]");
    const button = group.querySelector("[data-check-update]");
    if (!value || !hint || !button) return status;
    value.textContent = updateStateLabel(status);
    value.className = "check-value update-state " + (status?.state || "");
    const busy = status?.state === "checking" || status?.state === "downloading";
    button.disabled = busy;
    button.textContent = busy ? "正在处理…" : "检查网页更新";
    hint.textContent =
      status?.message ||
      "网页功能会热更新；通知、权限和原生能力变化才需要重新安装 APK。本地手账数据不会受影响。";
    return status;
  }

  function scheduleUpdateStatusPoll() {
    let attempts = 0;
    const timer = window.setInterval(() => {
      const status = refreshUpdatePanel();
      attempts += 1;
      if (!status || (status.state !== "checking" && status.state !== "downloading") || attempts >= 45) {
        window.clearInterval(timer);
      }
    }, 1000);
    refreshUpdatePanel();
    return timer;
  }

  function injectUpdateGroup() {
    const sheet = document.getElementById("settingsSheet");
    if (!sheet || document.getElementById("sg2UpdateGroup")) return;
    const group = document.createElement("div");
    group.className = "settings-group";
    group.id = "sg2UpdateGroup";
    group.innerHTML =
      '<div class="group-heading"><h3>应用更新</h3><span>网页热更新</span></div>' +
      '<div class="check-row"><span class="check-label">当前页面</span>' +
      '<span class="check-value update-state" data-update-version>正在读取…</span></div>' +
      '<button class="settings-action" type="button" data-check-update>检查网页更新</button>' +
      '<p class="check-hint" data-update-hint>检查通过后会先作为候选版本启动；页面异常时自动回退。</p>';

    group.addEventListener("click", (event) => {
      const button =
        event.target instanceof Element ? event.target.closest("[data-check-update]") : null;
      if (!button || !native || typeof native.checkForUpdates !== "function") return;
      button.disabled = true;
      button.textContent = "正在检查…";
      try {
        native.checkForUpdates();
        pageToast("正在检查网页更新");
      } catch (error) {
        button.disabled = false;
        button.textContent = "检查网页更新";
        pageToast("检查更新失败，请稍后重试");
      }
      scheduleUpdateStatusPoll();
    });

    const groups = Array.prototype.slice.call(sheet.querySelectorAll(".settings-group"));
    const dataGroup = groups.find((item) => item.textContent.indexOf("本地数据") >= 0);
    if (dataGroup && dataGroup.parentNode) {
      dataGroup.parentNode.insertBefore(group, dataGroup);
    } else {
      const saveButton = sheet.querySelector("#saveSettingsBtn");
      if (saveButton && saveButton.parentNode) saveButton.parentNode.insertBefore(group, saveButton);
      else sheet.appendChild(group);
    }
    refreshUpdatePanel();
  }

  function renderEnvironmentInfo() {
    const ua = navigator.userAgent || "";
    const chrome = /Chrome\/(\d+)/.exec(ua);
    const supports = (value) => {
      try {
        return window.CSS && CSS.supports && CSS.supports("color", value);
      } catch (error) {
        return false;
      }
    };
    const colorMix = supports("color-mix(in srgb, red, blue)");
    const fallbackOn = document.documentElement.getAttribute("data-colormix") === "fallback";
    const parts = [];
    parts.push(chrome ? "WebView " + chrome[1] : "非 Chrome 内核");
    parts.push("color-mix " + (colorMix ? "✓" : "✗"));
    if (fallbackOn) parts.push("已兜底");
    return parts.join(" · ");
  }

  /* --- APK 模式的外观兜底与原生引导 --- */
  function applyVisualCompat() {
    if (document.getElementById("sg2-visual-compat")) return;
    const style = document.createElement("style");
    style.id = "sg2-visual-compat";
    style.textContent = [
      ".topbar {",
      "  background-color: var(--accent, #2f7dff) !important;",
      "}",
      ".topbar-actions { position: relative; }",
      ".platform-credit-apk {",
      "  position: absolute; right: 47px; bottom: -6px;",
      "  color: rgba(255,255,255,.78); font-size: 6.5px; font-weight: 650;",
      "  letter-spacing: .01em; white-space: nowrap; pointer-events: none;",
      "}",
      ".sg2-apk #notificationSettings { display: none !important; }",
      "#sg2ReminderCheck .check-row {",
      "  display: flex; align-items: center; gap: 8px;",
      "  padding: 9px 12px; margin-bottom: 6px;",
      "  border-radius: 12px; background: var(--surface-soft);",
      "  border: 1px solid var(--line); font-size: 12px;",
      "}",
      "#sg2ReminderCheck .check-label { flex: 1; font-weight: 700; color: var(--text); }",
      "#sg2ReminderCheck .check-value { font-size: 11.5px; color: var(--muted); }",
      "#sg2ReminderCheck .check-value.is-ok { color: var(--success); }",
      "#sg2ReminderCheck .check-value.is-bad { color: var(--danger); }",
      "#sg2UpdateGroup .update-state.ready,",
      "#sg2UpdateGroup .update-state.installed,",
      "#sg2UpdateGroup .update-state.uptodate { color: var(--success); }",
      "#sg2UpdateGroup .update-state.error { color: var(--danger); }",
      "#sg2UpdateGroup .update-state.rolled-back { color: var(--danger); }",
      "#sg2UpdateGroup .update-state.checking,",
      "#sg2UpdateGroup .update-state.downloading { color: var(--accent); }",
      "#sg2UpdateGroup .settings-action[disabled] { opacity: .62; }",
      "#sg2ReminderCheck .check-button {",
      "  padding: 5px 9px; border-radius: 9px; font-size: 11px; font-weight: 700;",
      "  color: var(--accent); background: var(--surface-solid);",
      "  border: 1px solid var(--line-strong);",
      "}",
      "#sg2ReminderCheck .check-hint {",
      "  margin: 2px 0 8px; font-size: 11px; line-height: 1.5; color: var(--muted);",
      "}",
      "#sg2ReminderCheck .settings-action { width: 100%; }",
      ".sg2-version {",
      "  margin: 10px 0 0; text-align: center; font-size: 11px;",
      "  letter-spacing: 0.02em; color: var(--muted);",
      "}",
      ".sg2-diagnostic { margin-top: 2px; font-size: 10px; opacity: 0.72; }",
      ".apk-setup-backdrop {",
      "  position: fixed; z-index: 100; inset: 0; display: grid; place-items: center;",
      "  padding: 16px; background: rgba(5, 18, 38, .54); backdrop-filter: blur(16px);",
      "-webkit-backdrop-filter: blur(16px);",
      "}",
      ".apk-setup-card {",
      "  width: min(100%, 430px); max-height: min(90dvh, 760px); overflow-y: auto;",
      "  padding: 20px; color: var(--text); background: color-mix(in srgb, var(--surface-solid) 92%, transparent);",
      "  border: 1px solid rgba(255,255,255,.75); border-radius: 25px;",
      "  box-shadow: 0 24px 70px rgba(3,18,40,.32);",
      "}",
      ".apk-setup-kicker { color: var(--accent); font-size: 9px; font-weight: 850; letter-spacing: .13em; }",
      ".apk-setup-card h2 { margin: 4px 0 5px; font-size: 23px; letter-spacing: -.04em; }",
      ".apk-setup-intro { margin: 0 0 14px; color: var(--muted); font-size: 11px; line-height: 1.55; }",
      ".apk-setup-list { display: flex; flex-direction: column; gap: 7px; }",
      ".apk-setup-item {",
      "  display: grid; grid-template-columns: minmax(0,1fr) auto; align-items: center;",
      "  padding: 10px 11px; gap: 9px; background: var(--surface-soft);",
      "  border: 1px solid var(--line); border-radius: 13px;",
      "}",
      ".apk-setup-item strong { display: block; font-size: 11px; }",
      ".apk-setup-item small { display: block; margin-top: 2px; color: var(--muted); font-size: 9px; line-height: 1.4; }",
      ".apk-setup-item button { min-height: 32px; padding: 5px 9px; color: var(--accent);",
      "  background: var(--surface-solid); border: 1px solid var(--line-strong); border-radius: 9px;",
      "  font-size: 9px; font-weight: 800; }",
      ".apk-setup-lock { display: flex; align-items: flex-start; margin-top: 10px; padding: 10px 11px;",
      "  gap: 8px; color: var(--muted); background: color-mix(in srgb, var(--accent-soft) 62%, transparent);",
      "  border-radius: 12px; font-size: 9px; line-height: 1.5; }",
      ".apk-setup-lock input { margin-top: 2px; accent-color: var(--accent); }",
      ".apk-setup-actions { display: grid; grid-template-columns: 1fr 1.4fr; margin-top: 14px; gap: 8px; }",
      ".apk-setup-actions button { min-height: 44px; border-radius: 12px; font-size: 11px; font-weight: 800; }",
      ".apk-setup-later { color: var(--muted); background: var(--surface-soft); border: 1px solid var(--line); }",
      ".apk-setup-finish { color: var(--on-accent); background: linear-gradient(135deg, var(--accent), var(--accent-strong)); }",
      ".apk-setup-note { margin: 9px 0 0; color: var(--faint); font-size: 8.5px; text-align: center; }",
    ].join("\n");
    document.head.appendChild(style);
  }

  /* --- 状态栏跟随主题配色 --- */
  function parseHex(value) {
    const match = /^#([0-9a-f]{3,8})$/i.exec(String(value || "").trim());
    if (!match) return null;
    let hex = match[1];
    if (hex.length === 3) hex = hex.split("").map((c) => c + c).join("");
    if (hex.length < 6) return null;
    return {
      r: parseInt(hex.slice(0, 2), 16),
      g: parseInt(hex.slice(2, 4), 16),
      b: parseInt(hex.slice(4, 6), 16),
    };
  }

  function syncStatusBar() {
    if (!native || typeof native.setStatusBarColor !== "function") return;
    const styles = getComputedStyle(root);
    const bg = styles.getPropertyValue("--bg");
    const parsed = parseHex(bg);
    if (!parsed) return;
    const darkIcons = (0.299 * parsed.r + 0.587 * parsed.g + 0.114 * parsed.b) / 255 > 0.6;
    try {
      native.setStatusBarColor(String(bg).trim(), darkIcons);
    } catch (error) {
      /* 忽略：老版本壳可能没有这个方法 */
    }
  }

  function boot() {
    applyVisualCompat();
    injectPlatformCredit();
    injectReminderToggle();
    injectReminderCheck();
    injectUpdateGroup();
    injectVersionFooter();
    syncStatusBar();
    syncReminders();
    window.setTimeout(() => injectPermissionOnboarding(), 450);

    const settingsButton = document.getElementById("settingsBtn");
    if (settingsButton) {
      settingsButton.addEventListener("click", () => setTimeout(refreshReminderChecks, 80));
    }

    // Keep settings reachable even if a platform-specific enhancement fails.
    document.addEventListener(
      "click",
      (event) => {
        const target = event.target instanceof Element ? event.target : null;
        if (!target || !target.closest("#settingsBtn")) return;
        setTimeout(() => {
          const sheet = document.getElementById("settingsSheet");
          if (!sheet || sheet.classList.contains("open")) return;
          sheet.classList.add("open");
          document.body.style.overflow = "hidden";
        }, 120);
      },
      true
    );

    const observer = new MutationObserver(syncStatusBar);
    observer.observe(root, { attributes: true, attributeFilter: ["data-mode", "data-theme", "class", "style"] });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) {
        syncStatusBar();
        syncReminders();
        refreshReminderChecks();
        refreshUpdatePanel();
      }
    });

    if (native && typeof native.confirmUpdate === "function") {
      window.addEventListener(
        "sg2-app-ready",
        () => {
          try {
            native.confirmUpdate();
            refreshUpdatePanel();
          } catch (error) {
            /* 候选版本会在下次启动自动回退 */
          }
        },
        { once: true }
      );
    }

    if (native && typeof native.checkForUpdates === "function") {
      window.setTimeout(() => {
        try {
          native.checkForUpdates();
          scheduleUpdateStatusPoll();
        } catch (error) {
          /* 自动检查失败时继续使用当前版本 */
        }
      }, 1800);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  /* --- 给原生层的小标记，方便调试 --- */
  root.setAttribute("data-sg2-runtime", native ? "apk" : "apk-simulated");
})();
