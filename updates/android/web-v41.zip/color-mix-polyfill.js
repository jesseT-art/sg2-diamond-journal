/*
 * color-mix() 兜底
 * ---------------------------------------------------------------
 * 浏览器支持 color-mix() 就完全不动（现代引擎渲染结果不变）。
 * 不支持时：读取 styles.css，把所有 color-mix(...) 用当前主题的 CSS 变量算成 rgba()，
 * 再注入一份等价样式表 —— 这样老 WebView 的颜色和新引擎一致，
 * 也就不会再出现「顶栏白字压在透明底上」「卡片没有底色」这种差异。
 */
(function () {
  "use strict";

  const forceOff = /(?:^|[?&])nocolormix=1(?:&|$)/.test(location.search);
  const supported =
    !forceOff &&
    !!(window.CSS && window.CSS.supports && window.CSS.supports("color", "color-mix(in srgb, red, blue)"));
  if (supported) return;

  let styleEl = null;
  let sourceText = null;
  let applying = false;

  /* ---------- 颜色解析 ---------- */

  const NAMED = { white: [255, 255, 255, 1], black: [0, 0, 0, 1], red: [255, 0, 0, 1], blue: [0, 0, 255, 1] };
  let probeEl = null;

  /** 把浏览器认得的任何颜色写法（含 white 这类命名色）解析成 [r,g,b,a] */
  function parseColorViaDom(text) {
    try {
      if (!probeEl) {
        probeEl = document.createElement("span");
        probeEl.style.display = "none";
        (document.body || document.documentElement).appendChild(probeEl);
      }
      probeEl.style.color = "rgb(1, 2, 3)";
      probeEl.style.color = text;
      const computed = getComputedStyle(probeEl).color;
      if (!computed || computed === "rgb(1, 2, 3)") return null;
      return parseColor(computed) || parseColorNamed(computed);
    } catch (error) {
      return null;
    }
  }

  function parseColorNamed(value) {
    // getComputedStyle 一般会返回 rgb()/rgba()，这里只是兜底
    const named = NAMED[String(value).trim().toLowerCase()];
    return named ? named.slice() : null;
  }

  function parseColor(token) {
    const value = String(token || "").trim();
    if (!value) return null;
    if (value === "transparent") return [0, 0, 0, 0];
    if (value === "currentColor" || value === "currentcolor") return null;

    if (value.charAt(0) === "#") {
      let hex = value.slice(1);
      if (hex.length === 3) hex = hex.split("").map((c) => c + c).join("");
      if (hex.length !== 6 && hex.length !== 8) return null;
      const rgb = [
        parseInt(hex.slice(0, 2), 16),
        parseInt(hex.slice(2, 4), 16),
        parseInt(hex.slice(4, 6), 16),
      ];
      const alpha = hex.length === 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1;
      return [rgb[0], rgb[1], rgb[2], alpha];
    }

    const match = /^rgba?\(([^)]+)\)$/i.exec(value);
    if (match) {
      const parts = match[1].trim().split(/[\s,/]+/).filter(Boolean);
      if (parts.length < 3) return null;
      const nums = parts.slice(0, 3).map((n) => Number(n));
      if (nums.some((n) => Number.isNaN(n))) return null;
      let alpha = 1;
      if (parts[3] != null) {
        alpha = parts[3].indexOf("%") >= 0 ? parseFloat(parts[3]) / 100 : Number(parts[3]);
        if (Number.isNaN(alpha)) alpha = 1;
      }
      return [nums[0], nums[1], nums[2], Math.max(0, Math.min(1, alpha))];
    }

    const named = parseColorNamed(value);
    if (named) return named;
    return parseColorViaDom(value);
  }

  function resolveVars(text) {
    return String(text).replace(
      /var\(\s*(--[A-Za-z0-9_-]+)\s*(?:,\s*([^()]*(?:\([^()]*\)[^()]*)*))?\)/g,
      (whole, name, fallback) => {
        const computed = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
        if (computed) return computed;
        const fb = (fallback || "").trim();
        return fb || whole;
      }
    );
  }

  /* ---------- 顶层逗号切分（rgba(...) 里的逗号不算） ---------- */

  function splitTopLevel(text, separator) {
    const out = [];
    let depth = 0;
    let current = "";
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === "(") depth++;
      else if (ch === ")") depth--;
      if (ch === separator && depth === 0) {
        out.push(current);
        current = "";
      } else {
        current += ch;
      }
    }
    out.push(current);
    return out;
  }

  /* ---------- 单个 color-mix 计算 ---------- */

  function computeMix(inner) {
    const resolved = resolveVars(inner);
    const syntax = /^\s*in\s+srgb\s*,\s*([\s\S]+)$/i.exec(resolved);
    if (!syntax) return null;

    const parts = splitTopLevel(syntax[1], ",").map((p) => p.trim());
    if (parts.length !== 2) return null;

    const operands = [];
    for (const part of parts) {
      const colorMatch = /^(.*?)\s*([\d.]+%)\s*$/.exec(part);
      const colorText = colorMatch ? colorMatch[1] : part;
      const percent = colorMatch ? parseFloat(colorMatch[2]) / 100 : null;
      const rgba = parseColor(colorText);
      if (!rgba) return null;
      operands.push({ rgba, percent });
    }

    let [w1, w2] = [operands[0].percent, operands[1].percent];
    if (w1 == null && w2 == null) {
      w1 = 0.5;
      w2 = 0.5;
    } else if (w1 == null) {
      w1 = 1 - w2;
    } else if (w2 == null) {
      w2 = 1 - w1;
    }
    const sum = w1 + w2;
    if (!(sum > 0)) return null;
    w1 = w1 / sum;
    w2 = w2 / sum;

    const c1 = operands[0].rgba;
    const c2 = operands[1].rgba;
    const alpha = w1 * c1[3] + w2 * c2[3];
    if (alpha <= 0) return "rgba(0, 0, 0, 0)";

    const channel = (i) => Math.round((w1 * c1[3] * c1[i] + w2 * c2[3] * c2[i]) / alpha);
    return `rgba(${channel(0)}, ${channel(1)}, ${channel(2)}, ${Number(alpha.toFixed(3))})`;
  }

  /* ---------- 整段 CSS 里替换所有 color-mix(...) ---------- */

  function transform(cssText) {
    let out = "";
    let index = 0;
    while (index < cssText.length) {
      const start = cssText.toLowerCase().indexOf("color-mix(", index);
      if (start < 0) {
        out += cssText.slice(index);
        break;
      }
      out += cssText.slice(index, start);
      let depth = 0;
      let end = -1;
      for (let i = start + "color-mix".length; i < cssText.length; i++) {
        if (cssText[i] === "(") depth++;
        else if (cssText[i] === ")") {
          depth--;
          if (depth === 0) {
            end = i;
            break;
          }
        }
      }
      if (end < 0) {
        out += cssText.slice(start);
        break;
      }
      const inner = cssText.slice(start + "color-mix(".length, end);
      let replacement = null;
      try {
        replacement = computeMix(inner);
      } catch (error) {
        replacement = null;
      }
      out += replacement || cssText.slice(start, end + 1);
      index = end + 1;
    }
    return out;
  }

  /* ---------- 注入 ---------- */

  function apply() {
    if (!sourceText || applying) return;
    applying = true;
    try {
      const transformed = transform(sourceText);
      if (!styleEl) {
        styleEl = document.createElement("style");
        styleEl.id = "sg2-colormix-fallback";
        (document.head || document.documentElement).appendChild(styleEl);
      }
      styleEl.textContent = transformed;
      document.documentElement.setAttribute("data-colormix", "fallback");
    } catch (error) {
      console.warn("color-mix 兜底失败，保持原样式。", error);
    } finally {
      applying = false;
    }
  }

  async function load() {
    try {
      const response = await fetch("./styles.css", { cache: "no-store" });
      if (!response.ok) throw new Error("HTTP " + response.status);
      sourceText = await response.text();
      apply();
    } catch (error) {
      console.warn("color-mix 兜底：读取样式失败。", error);
    }
  }

  function watch() {
    // 主题/深色模式切换后颜色变量变了，需要重算
    let timer = 0;
    const schedule = () => {
      clearTimeout(timer);
      timer = setTimeout(apply, 40);
    };
    try {
      const observer = new MutationObserver(schedule);
      observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ["data-theme", "data-mode", "class", "style"],
      });
    } catch (error) {
      /* 忽略 */
    }
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) schedule();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      load();
      watch();
    });
  } else {
    load();
    watch();
  }
})();
